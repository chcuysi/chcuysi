package controller;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import service.SalesEtcService;
import vo.SalesCategoryVO;

//카테고리별 매출(기타) 컨트롤러
@Controller
public class SalesEtcController {
	
	// 의존성 주입
    @Autowired
    private SalesEtcService salesEtcService;
    
    // 카테고리별 매출(기타) 출력
    @RequestMapping("salesEtc.do")
    public void getSalesEtc(SalesCategoryVO scvo, Model m) {
    	
    	// HashMap 객체 생성, 거기에 필요한 값들 넣기
        HashMap<String, Object> map = new HashMap<>();
        map.put("category", scvo.getCategory());
        map.put("category2", scvo.getCategory2());
        map.put("sell_total", scvo.getSell_total());

        // 그 값들을 카테고리별 매출(기타) 목록에 넣기(SalesEtcVO에 있는 값으로 한정)
        List<SalesCategoryVO> list = salesEtcService.getSalesEtc(map);
        // Model 객체에 카테고리별 매출(기타) 목록을 추가
        m.addAttribute("salesEtc", list);
    }
 }