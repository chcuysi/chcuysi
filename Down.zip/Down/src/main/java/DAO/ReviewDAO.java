package DAO;

import vo.ReviewVO;

public interface ReviewDAO {

	
	public void insertReview(ReviewVO vo);

}
