package Service;

import vo.ReviewVO;

public interface ReviewService {

	
	public void insertReview(ReviewVO vo);
	
	
	
	
	
}
