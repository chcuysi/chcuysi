package vo;


public class MemberVO {

	private String mid;
	private String mpw;
	private String mname;
	private String maddr;
	private String mdaddr;
	private String mtel;
	private String memail;
	private String mdate;
	private String mjnum;
	private String mcode;

	public String getMdaddr() {
		return mdaddr;
	}
	public void setMdaddr(String mdaddr) {
		this.mdaddr = mdaddr;
	}
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	public String getMpw() {
		return mpw;
	}
	public void setMpw(String mpw) {
		this.mpw = mpw;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public String getMaddr() {
		return maddr;
	}
	public void setMaddr(String maddr) {
		this.maddr = maddr;
	}
	public String getMtel() {
		return mtel;
	}
	public void setMtel(String mtel) {
		this.mtel = mtel;
	}
	public String getMemail() {
		return memail;
	}
	public void setMemail(String memail) {
		this.memail = memail;
	}
	public String getMdate() {
		return mdate;
	}
	public void setMdate(String mdate) {
		this.mdate = mdate;
	}
	public String getMjnum() {
		return mjnum;
	}
	public void setMjnum(String mjnum) {
		this.mjnum = mjnum;
	}
	public String getMcode() {
		return mcode;
	}
	public void setMcode(String mcode) {
		this.mcode = mcode;
	}


}
