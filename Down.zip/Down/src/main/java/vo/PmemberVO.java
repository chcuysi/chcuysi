package vo;


public class PmemberVO {

	private String pid;
	private String pnum;
	private String ppw;
	private String pname;
	private String paddr;
	private String pdaddr;
	private String ptel;
	private String pemail;
	private String pdate;
	private String pjnum;
	private String pcode;
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getPnum() {
		return pnum;
	}
	public void setPnum(String pnum) {
		this.pnum = pnum;
	}
	public String getPpw() {
		return ppw;
	}
	public void setPpw(String ppw) {
		this.ppw = ppw;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPaddr() {
		return paddr;
	}
	public void setPaddr(String paddr) {
		this.paddr = paddr;
	}
	public String getPdaddr() {
		return pdaddr;
	}
	public void setPdaddr(String pdaddr) {
		this.pdaddr = pdaddr;
	}
	public String getPtel() {
		return ptel;
	}
	public void setPtel(String ptel) {
		this.ptel = ptel;
	}
	public String getPemail() {
		return pemail;
	}
	public void setPemail(String pemail) {
		this.pemail = pemail;
	}
	public String getPdate() {
		return pdate;
	}
	public void setPdate(String pdate) {
		this.pdate = pdate;
	}
	public String getPjnum() {
		return pjnum;
	}
	public void setPjnum(String pjnum) {
		this.pjnum = pjnum;
	}
	public String getPcode() {
		return pcode;
	}
	public void setPcode(String pcode) {
		this.pcode = pcode;
	}
	
	
	

	
}
